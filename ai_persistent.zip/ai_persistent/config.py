#config.py
DEFAULT_MODEL = "llama3"
HISTORY_FILE = "chat_history.json"
